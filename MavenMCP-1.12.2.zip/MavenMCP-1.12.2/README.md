# Maven MCP 1.0-1.12.2

## About Maven MCP
Maven MCP is a framework for using MCP with maven.

## Info
VMOptions: `-Djava.library.path=versions/1.12.2/1.12.2-natives/` 

## Contribution
#### Strezz - [Github](https://github.com/strezzed) - [Twitter](https://twitter.com/STREZZS)
#### More
